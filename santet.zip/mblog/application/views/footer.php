				<section id="footer" class="page-section">
					<footer id="footer-section" class="page-section pt-30 pb-30 center-xs">					
						<div class="copyright fw300 mb-sm-10"><span>&copy; Mblog v2.0 <?php echo date('Y');?> </span></div>
						<div class="caption fw300">Made with <i class="lnr lnr-heart"></i> by <a href="https://api.whatsapp.com/send?phone=6285282828045&text=Saya%20tertarik%20untuk%20pesan%20website%20ini%20segera." target="_blank">Lapak Anak OGI</a></div>
						<!-- ACROLL TO TOP-->	
						<div class="top-button"><h5>Top</h5><div class="line"></div></div>
					</footer>
				</section>